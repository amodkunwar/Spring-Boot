package com.hdfs.com.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.hdfs.com.entity.Hdfs;
import com.hdfs.com.exception.ApplicationException;
import com.hdfs.com.implementation.HdfsServiceImpl;
import com.hdfs.com.model.HdfsRequest;
import com.hdfs.com.model.HdfsResponse;
import com.hdfs.com.repository.HdfsRepository;

@RunWith(SpringRunner.class)
public class HdfsServiceImplTest {

	@InjectMocks
	private HdfsServiceImpl hdfsServiceImpl;

	@Mock
	private HdfsRepository hdfsRepository;

	/***
	 * Positive scenario
	 */

	@Test
	public void testSaveHdfs() {
		Hdfs hdfs = new Hdfs();
		hdfs.setCobDate(LocalDate.now());
		hdfs.setGroupId(1L);
		HdfsRequest hdfsRequest = new HdfsRequest();
		hdfsRequest.setCobDate(LocalDate.now());
		hdfsRequest.setGroupId(1L);
		HdfsResponse hdfsResponse = new HdfsResponse();
		hdfsResponse.setCobDate(LocalDate.now());
		hdfsResponse.setGroupId(1L);
		Mockito.doReturn(hdfs).when(hdfsRepository).save(hdfs);
		hdfsServiceImpl.saveHdfs(hdfsRequest);
	}

	/***
	 * Negative scenario
	 * 
	 * passing the hdfsRequest as a null
	 */

	@Test(expected = ApplicationException.class)
	public void testSaveHdfs_null_hdfs() {
		HdfsRequest hdfsRequest = new HdfsRequest();
		hdfsRequest = null;
		hdfsServiceImpl.saveHdfs(hdfsRequest);
	}

	/***
	 * positive scenario
	 */

	@Test
	public void testGetAllHdfsLocationByGroupId() {
		Long groupId = 1L;
		List<Hdfs> getAllHdfsLocationByGroupId = new ArrayList<>();
		Hdfs hdfs = new Hdfs();
		hdfs.setCobDate(LocalDate.now());
		hdfs.setGroupId(1L);
		getAllHdfsLocationByGroupId.add(hdfs);
		Mockito.doReturn(getAllHdfsLocationByGroupId).when(hdfsRepository).getAllHdfsLocationByGroupId(groupId);
		hdfsServiceImpl.getAllHdfsLocationByGroupId(groupId);
	}

	/***
	 * Negative scenario
	 * 
	 * Passing group Id as a null
	 */

	@Test(expected = ApplicationException.class)
	public void testGetAllHdfsLocationByGroupId_null_groupId() {
		Long groupId = null;
		hdfsServiceImpl.getAllHdfsLocationByGroupId(groupId);
	}

}
