package com.hdfs.com.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.hdfs.com.entity.Hdfs;
import com.hdfs.com.model.HdfsRequest;
import com.hdfs.com.model.HdfsResponse;
import com.hdfs.com.service.HdfsService;

@RunWith(SpringRunner.class)
public class HdfsControllerTest {

	@InjectMocks
	private HdfsController hdfsController;

	@Mock
	private HdfsService hdfsService;

	@Test
	public void testSaveHdfs() {
		HdfsRequest hdfsRequest = new HdfsRequest();
		hdfsRequest.setCobDate(LocalDate.now());
		hdfsRequest.setGroupId(1L);
		HdfsResponse hdfsResponse = new HdfsResponse();
		hdfsResponse.setCobDate(LocalDate.now());
		hdfsResponse.setGroupId(1L);
		Mockito.doReturn(hdfsResponse).when(hdfsService).saveHdfs(hdfsRequest);
		hdfsController.saveHdfs(hdfsRequest);
	}

	@Test
	public void testGetAllHdfsLocationByGroupId() {
		Long groupId = 1L;
		List<Hdfs> getAllHdfsLocationByGroupId = new ArrayList<>();
		Hdfs hdfs = new Hdfs();
		hdfs.setCobDate(LocalDate.now());
		hdfs.setGroupId(1L);
		getAllHdfsLocationByGroupId.add(hdfs);
		Mockito.doReturn(getAllHdfsLocationByGroupId).when(hdfsService).getAllHdfsLocationByGroupId(groupId);
		hdfsController.getHdfsByGroupId(groupId);
	}

}
