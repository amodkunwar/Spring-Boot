package com.hdfs.com;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HdfsLocationApplicationTests {

	@Test
	void contextLoads() {
	}

}
