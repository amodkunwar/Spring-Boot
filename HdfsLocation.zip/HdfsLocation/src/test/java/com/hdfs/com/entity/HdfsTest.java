package com.hdfs.com.entity;

import static org.junit.Assert.assertEquals;

import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.hdfs.com.utility.HdfsUtility;

@RunWith(SpringRunner.class)
public class HdfsTest {

	@Test
	public void test() {
		Hdfs hdfs = new Hdfs();
		hdfs.setCobDate(LocalDate.now(Clock.fixed(Instant.now(), ZoneId.of("GMT"))));
		hdfs.setGroupId(1L);
		hdfs.setHdfsId(HdfsUtility.getUUID());
		LocalDate date = hdfs.getCobDate();
		Long groupId = hdfs.getGroupId();
		String hdfsId = hdfs.getHdfsId();
		assertEquals(hdfsId, hdfs.getHdfsId());
		assertEquals(groupId, hdfs.getGroupId());
		assertEquals(date, hdfs.getCobDate());
	}

}
