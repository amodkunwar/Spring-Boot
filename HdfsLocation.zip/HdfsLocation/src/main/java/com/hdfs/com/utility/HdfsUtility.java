package com.hdfs.com.utility;

import java.util.UUID;

/***
 * 
 * @author Amod
 *
 */

public class HdfsUtility {
	
	/***
	 * 
	 * @return String
	 * 
	 * THis is utility class which will call to generate the UUID.
	 */

	public static String getUUID() {
		UUID randomUUID = UUID.randomUUID();
		return randomUUID.toString();
	}

}
