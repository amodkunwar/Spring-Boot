package com.hdfs.com.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.hdfs.com.entity.Hdfs;
import com.hdfs.com.model.HdfsRequest;
import com.hdfs.com.model.HdfsResponse;
import com.hdfs.com.service.HdfsService;

/***
 * 
 * @author Amod
 *
 */

@RestController
@RequestMapping("/hdfs")
public class HdfsController {

	@Autowired
	private HdfsService hdfsService;

	/***
	 * @param hdfsRequest
	 * @return HdfsResponse
	 * 
	 *         This method is of controller level. Whenever Api will call it will
	 *         come to controller level first From controller It will go to the
	 *         service layer and from service layer it will call the corresponding
	 *         repository
	 */

	@PostMapping("/add")
	public @ResponseBody HdfsResponse saveHdfs(@RequestBody @Valid @NotNull HdfsRequest hdfsRequest) {
		// calling save method of service class
		HdfsResponse hdfsResponse = hdfsService.saveHdfs(hdfsRequest);
		return hdfsResponse;
	}

	/***
	 * @param groupId
	 * @return List<Hdfs>
	 * 
	 *         This method is used to return the Hdfs based on Group Id
	 */

	@GetMapping("/get/{groupId}")
	public @ResponseBody List<Hdfs> getHdfsByGroupId(@Valid @NotNull @PathVariable("groupId") Long groupId) {
		//calling getAllHdfsLocationByGroupId() of service Class
		return hdfsService.getAllHdfsLocationByGroupId(groupId);
	}

}
