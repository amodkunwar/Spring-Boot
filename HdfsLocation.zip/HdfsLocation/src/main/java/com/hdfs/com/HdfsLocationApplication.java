package com.hdfs.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HdfsLocationApplication {

	public static void main(String[] args) {
		SpringApplication.run(HdfsLocationApplication.class, args);
	}

}
