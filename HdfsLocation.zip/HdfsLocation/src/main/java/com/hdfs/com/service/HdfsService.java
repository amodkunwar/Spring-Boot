package com.hdfs.com.service;

import java.util.List;

import com.hdfs.com.entity.Hdfs;
import com.hdfs.com.model.HdfsRequest;
import com.hdfs.com.model.HdfsResponse;

/***
 * 
 * @author Amod
 *
 */

public interface HdfsService {

	/***
	 * 
	 * @param hdfsRequest
	 * @return HdfsResponse
	 * 
	 *         This method is used to save the HDFS which is coming from request
	 */

	public HdfsResponse saveHdfs(HdfsRequest hdfsRequest);

	/***
	 * 
	 * @param groupId
	 * @return List<Hdfs>
	 * 
	 *         This method is used to return the Hdfs based on Group Id
	 */

	public List<Hdfs> getAllHdfsLocationByGroupId(Long groupId);

}
