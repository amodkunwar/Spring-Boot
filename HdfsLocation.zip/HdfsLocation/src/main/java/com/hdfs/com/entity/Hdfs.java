package com.hdfs.com.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.hdfs.com.utility.HdfsUtility;

/***
 * 
 * @author Amod
 *
 */

@Entity
@Table(name = "HDFS")
public class Hdfs {

	@Id
	@Column(name = "HDFS_ID")
	private String hdfsId = HdfsUtility.getUUID();

	@Column(name = "COB_DATE")
	private LocalDate cobDate;

	@Column(name = "GROUP_ID")
	private Long groupId;

	public Hdfs() {
		System.out.println(this.getClass().getSimpleName() + " class object created");
	}

	public String getHdfsId() {
		return hdfsId;
	}

	public void setHdfsId(String hdfsId) {
		this.hdfsId = hdfsId;
	}

	public LocalDate getCobDate() {
		return cobDate;
	}

	public void setCobDate(LocalDate cobDate) {
		this.cobDate = cobDate;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	@Override
	public String toString() {
		return "Hdfs [hdfsId=" + hdfsId + ", cobDate=" + cobDate + ", groupId=" + groupId + "]";
	}

}
