package com.hdfs.com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hdfs.com.entity.Hdfs;

/***
 * 
 * @author Amod
 *
 */

@Repository
public interface HdfsRepository extends JpaRepository<Hdfs, String> {

	/***
	 * 
	 * @param groupId
	 * @return List<Hdfs>
	 * 
	 *         This method is used to return all the Hdfs location based on group Id
	 */

	@Query("SELECT h FROM Hdfs h where h.groupId = :groupId")
	public List<Hdfs> getAllHdfsLocationByGroupId(@Param("groupId") Long groupId);

}
