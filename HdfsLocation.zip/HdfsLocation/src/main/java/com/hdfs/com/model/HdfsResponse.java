package com.hdfs.com.model;

import java.time.LocalDate;

/***
 * 
 * @author Amod
 *
 *         This is the Pojo class for Response of HDFS location
 */

public class HdfsResponse {

	private LocalDate cobDate;
	private Long groupId;

	public LocalDate getCobDate() {
		return cobDate;
	}

	public void setCobDate(LocalDate cobDate) {
		this.cobDate = cobDate;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

}
