package com.hdfs.com.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author Amod
 * 
 *         This is the Pojo class for Request of HDFS location
 *
 */
public class HdfsRequest {

	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate cobDate;

	private Long groupId;

	public LocalDate getCobDate() {
		return cobDate;
	}

	public void setCobDate(LocalDate cobDate) {
		this.cobDate = cobDate;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

}
