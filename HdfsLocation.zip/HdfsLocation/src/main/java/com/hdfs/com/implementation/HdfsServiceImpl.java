package com.hdfs.com.implementation;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hdfs.com.entity.Hdfs;
import com.hdfs.com.exception.ApplicationException;
import com.hdfs.com.model.HdfsRequest;
import com.hdfs.com.model.HdfsResponse;
import com.hdfs.com.repository.HdfsRepository;
import com.hdfs.com.service.HdfsService;

/***
 * 
 * @author Amod
 *
 */

@Service
@Transactional
public class HdfsServiceImpl implements HdfsService {

	private static final Logger HdfsLogger = LoggerFactory.getLogger(HdfsServiceImpl.class);

	@Autowired
	private HdfsRepository hdfsRepository;

	/***
	 * 
	 * @param hdfsRequest
	 * @return HdfsResponse
	 * 
	 *         This method is used to save the HDFS which is coming from request
	 */

	@Override
	public HdfsResponse saveHdfs(HdfsRequest hdfsRequest) {
		Hdfs hdfs = new Hdfs();
		HdfsResponse hdfsResponse = null;

		/***
		 * validation of HdfsRequest Save the Hdfs in database Return HdfsResponse
		 */

		if (null != hdfsRequest) {
			hdfs.setCobDate(hdfsRequest.getCobDate());
			hdfs.setGroupId(hdfsRequest.getGroupId());
			try {
				// save Repo call
				hdfsRepository.save(hdfs);
				// get response
				hdfsResponse = getResponse(hdfs);
			} catch (Exception e) {
				HdfsLogger.error("Failed to save the data : ".concat(e.getMessage()));
			}
		} else {
			HdfsLogger.error("Request can not be null/Empty : ");
			throw new ApplicationException("Request cannot be null/Empty");
		}
		return hdfsResponse;
	}

	/***
	 * @param hdfs
	 * @return HdfsResponse
	 * 
	 *         This method is used to set the Response for Hdfs
	 */

	private HdfsResponse getResponse(Hdfs hdfs) {
		HdfsResponse hdfsResponse = new HdfsResponse();

		/***
		 * Setting the response
		 */

		hdfsResponse.setCobDate(hdfs.getCobDate());
		hdfsResponse.setGroupId(hdfs.getGroupId());
		return hdfsResponse;
	}

	/***
	 * 
	 * @param groupId
	 * @return List<Hdfs>
	 * 
	 *         This method is used to return the Hdfs based on Group Id
	 */

	public List<Hdfs> getAllHdfsLocationByGroupId(Long groupId) {
		List<Hdfs> getAllHdfsLocationByGroupId = null;
		if (null != groupId) {
			getAllHdfsLocationByGroupId = hdfsRepository.getAllHdfsLocationByGroupId(groupId);
			if (null == getAllHdfsLocationByGroupId || getAllHdfsLocationByGroupId.isEmpty()) {
				HdfsLogger.error("Group Id does not exist");
				throw new ApplicationException("Group Id does not exist");
			}
		} else {
			HdfsLogger.error("Group Id can not be null/Empty : ");
			throw new ApplicationException("Group Id can not be null/Empty");
		}
		return getAllHdfsLocationByGroupId;
	}

}
